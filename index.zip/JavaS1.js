setTimeout(function(){location.href = "index1.html";},1000);

