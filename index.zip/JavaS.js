function blure(){
    $("body").addClass("bluring");
    $("body").addClass("text-confirmation");
    $(".fon").remove();
    setTimeout(oupen2 ,1000);
   
}
function oupen2(){
    location.href = "index3.html"
}


$(".btn").click(function(){
    $(".modal-canvas").toggleClass("hidden");
    $(".screensaver1").toggleClass("hidden");
});
$(".modal-close").click(function(){
    $(".modal-canvas").toggleClass("hidden");
    $(".screensaver1").toggleClass("hidden");
});